<?php
/**
 * Plugin Name: WC M-Pesa STK Push (Daraja API 2.0)
 * Plugin URI:  https://createch-hobbies.co.ke
 * Description: WooCommerce payment gateway for Safaricom M-Pesa Express (STK Push) via Daraja API 2.0.
 * Version:     1.0.0
 * Author:      Createch Hobbies
 * License:     GPL-2.0+
 * Text Domain: wc-mpesa-stk
 */

defined( 'ABSPATH' ) || exit;

// ------------------------------------------------------------------
// 1. Boot: register the gateway only after WooCommerce is loaded.
// ------------------------------------------------------------------
add_action( 'plugins_loaded', 'wc_mpesa_stk_init', 11 );

function wc_mpesa_stk_init() {
    if ( ! class_exists( 'WC_Payment_Gateway' ) ) {
        add_action( 'admin_notices', function () {
            echo '<div class="error"><p><strong>WC M-Pesa STK Push</strong> requires WooCommerce to be active.</p></div>';
        } );
        return;
    }

    // Register gateway class.
    add_filter( 'woocommerce_payment_gateways', 'wc_mpesa_stk_add_gateway' );
    function wc_mpesa_stk_add_gateway( $gateways ) {
        $gateways[] = 'WC_Gateway_Mpesa_STK';
        return $gateways;
    }

    // ---------------------------------------------------------------
    // 2. Main gateway class.
    // ---------------------------------------------------------------
    class WC_Gateway_Mpesa_STK extends WC_Payment_Gateway {

        /** @var WC_Logger */
        private WC_Logger $log;

        public function __construct() {
            $this->id                 = 'wc_mpesa_stk';
            $this->method_title       = 'M-Pesa STK Push';
            $this->method_description = 'Accept payments via Safaricom M-Pesa Express (STK Push) using Daraja API 2.0.';
            $this->has_fields         = true; // Show phone number field at checkout
            $this->supports           = [ 'products' ];

            $this->init_form_fields();
            $this->init_settings();

            // Pull values from saved settings.
            $this->title       = $this->get_option( 'title' );
            $this->description = $this->get_option( 'description' );

            $this->log = new WC_Logger();

            // Save admin settings when updated.
            add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, [ $this, 'process_admin_options' ] );

            // Register the Safaricom callback endpoint.
            // Callback URL format: https://yoursite.com/wc-api/wc_gateway_mpesa_stk/
            add_action( 'woocommerce_api_wc_gateway_mpesa_stk', [ $this, 'handle_callback' ] );
        }

        // -----------------------------------------------------------
        // 3. Admin Settings Form Fields.
        // -----------------------------------------------------------
        public function init_form_fields(): void {
            $this->form_fields = [
                'enabled' => [
                    'title'   => 'Enable/Disable',
                    'type'    => 'checkbox',
                    'label'   => 'Enable M-Pesa STK Push',
                    'default' => 'no',
                ],
                'title' => [
                    'title'       => 'Title',
                    'type'        => 'text',
                    'description' => 'Payment title shown to the customer at checkout.',
                    'default'     => 'M-Pesa',
                    'desc_tip'    => true,
                ],
                'description' => [
                    'title'       => 'Description',
                    'type'        => 'textarea',
                    'description' => 'Payment description shown to the customer at checkout.',
                    'default'     => 'Pay securely via M-Pesa. You will receive a push notification on your phone to confirm.',
                ],
                'environment' => [
                    'title'       => 'Environment',
                    'type'        => 'select',
                    'description' => 'Use Sandbox for testing, Production for live payments.',
                    'desc_tip'    => true,
                    'default'     => 'sandbox',
                    'options'     => [
                        'sandbox'    => 'Sandbox (Testing)',
                        'production' => 'Production (Live)',
                    ],
                ],
                'shortcode' => [
                    'title'       => 'Paybill / Till Number',
                    'type'        => 'text',
                    'description' => 'Your Safaricom Paybill or Business Till Number (Shortcode).',
                    'desc_tip'    => true,
                    'default'     => '',
                ],
                'consumer_key' => [
                    'title'       => 'Consumer Key',
                    'type'        => 'text',
                    'description' => 'Daraja API Consumer Key from the Safaricom Developer Portal.',
                    'desc_tip'    => true,
                    'default'     => '',
                ],
                'consumer_secret' => [
                    'title'       => 'Consumer Secret',
                    'type'        => 'password',
                    'description' => 'Daraja API Consumer Secret from the Safaricom Developer Portal.',
                    'desc_tip'    => true,
                    'default'     => '',
                ],
                'passkey' => [
                    'title'       => 'Passkey',
                    'type'        => 'password',
                    'description' => 'STK Push Passkey from the Safaricom Developer Portal (Lipa na M-Pesa Online Passkey).',
                    'desc_tip'    => true,
                    'default'     => '',
                ],
            ];
        }

        // -----------------------------------------------------------
        // 4. Checkout: render the phone number input field.
        // -----------------------------------------------------------
        public function payment_fields(): void {
            if ( $this->description ) {
                echo '<p>' . wp_kses_post( $this->description ) . '</p>';
            }

            echo '<fieldset id="wc-mpesa-stk-fields">';
            echo '<div class="form-row form-row-wide">';
            echo '<label for="mpesa_phone">' . esc_html__( 'M-Pesa Phone Number', 'wc-mpesa-stk' ) . ' <span class="required">*</span></label>';
            echo '<input type="tel" id="mpesa_phone" name="mpesa_phone" placeholder="e.g. 2547XXXXXXXX" maxlength="12" autocomplete="tel" />';
            echo '<small>' . esc_html__( 'Enter your number in the format: 2547XXXXXXXX or 2541XXXXXXXX', 'wc-mpesa-stk' ) . '</small>';
            echo '</div>';
            echo '</fieldset>';
        }

        // -----------------------------------------------------------
        // 5. Checkout: validate the phone number before order is placed.
        // -----------------------------------------------------------
        public function validate_fields(): bool {
            $phone = isset( $_POST['mpesa_phone'] ) ? sanitize_text_field( wp_unslash( $_POST['mpesa_phone'] ) ) : '';

            if ( empty( $phone ) ) {
                wc_add_notice( 'Please enter your M-Pesa phone number.', 'error' );
                return false;
            }

            // Accept 2547XXXXXXXX (Safaricom) and 2541XXXXXXXX (Airtel, future-proof).
            if ( ! preg_match( '/^254[71]\d{8}$/', $phone ) ) {
                wc_add_notice( 'Invalid M-Pesa number. Use the format: 2547XXXXXXXX or 2541XXXXXXXX.', 'error' );
                return false;
            }

            return true;
        }

        // -----------------------------------------------------------
        // 6. process_payment — called when the customer places the order.
        // -----------------------------------------------------------
        public function process_payment( $order_id ): array {
            $order = wc_get_order( $order_id );
            $phone = sanitize_text_field( wp_unslash( $_POST['mpesa_phone'] ?? '' ) );

            // Step 1: Get OAuth access token.
            $token = $this->get_access_token();
            if ( is_wp_error( $token ) ) {
                $this->log->error( '[M-Pesa STK] Token error: ' . $token->get_error_message(), [ 'source' => 'mpesa-stk' ] );
                wc_add_notice( 'M-Pesa service is temporarily unavailable. Please try again.', 'error' );
                return [ 'result' => 'failure' ];
            }

            // Step 2: Build STK Push password.
            $shortcode = $this->get_option( 'shortcode' );
            $passkey   = $this->get_option( 'passkey' );
            $timestamp = gmdate( 'YmdHis' );
            $password  = base64_encode( $shortcode . $passkey . $timestamp );

            // Amount must be a whole number (KES).
            $amount = (int) ceil( $order->get_total() );

            // Callback URL that Safaricom will POST results to.
            $callback_url = add_query_arg( 'wc-api', 'wc_gateway_mpesa_stk', trailingslashit( get_home_url() ) );

            $payload = [
                'BusinessShortCode' => $shortcode,
                'Password'          => $password,
                'Timestamp'         => $timestamp,
                'TransactionType'   => 'CustomerPayBillOnline', // Change to 'CustomerBuyGoodsOnline' for Till numbers
                'Amount'            => $amount,
                'PartyA'            => $phone,
                'PartyB'            => $shortcode,
                'PhoneNumber'       => $phone,
                'CallBackURL'       => $callback_url,
                'AccountReference'  => 'Order #' . $order_id,
                'TransactionDesc'   => 'Payment for Order #' . $order_id . ' at Createch Hobbies',
            ];

            $this->log->info(
                '[M-Pesa STK] STK Push request for Order #' . $order_id . ': ' . wp_json_encode( array_merge( $payload, [ 'Password' => '***' ] ) ),
                [ 'source' => 'mpesa-stk' ]
            );

            // Step 3: Send STK Push request.
            $response = wp_remote_post(
                $this->get_endpoint( 'stkpush' ),
                [
                    'headers' => [
                        'Authorization' => 'Bearer ' . $token,
                        'Content-Type'  => 'application/json',
                    ],
                    'body'    => wp_json_encode( $payload ),
                    'timeout' => 30,
                ]
            );

            if ( is_wp_error( $response ) ) {
                $this->log->error( '[M-Pesa STK] STK Push request failed: ' . $response->get_error_message(), [ 'source' => 'mpesa-stk' ] );
                wc_add_notice( 'Could not reach M-Pesa. Check your connection and try again.', 'error' );
                return [ 'result' => 'failure' ];
            }

            $body = json_decode( wp_remote_retrieve_body( $response ), true );
            $this->log->info( '[M-Pesa STK] STK Push response: ' . wp_json_encode( $body ), [ 'source' => 'mpesa-stk' ] );

            // Step 4: Handle API response.
            if ( isset( $body['ResponseCode'] ) && '0' === (string) $body['ResponseCode'] ) {
                // Store CheckoutRequestID so the callback can match the order.
                $order->update_meta_data( '_mpesa_checkout_request_id', sanitize_text_field( $body['CheckoutRequestID'] ) );
                $order->update_meta_data( '_mpesa_merchant_request_id', sanitize_text_field( $body['MerchantRequestID'] ) );
                $order->save();

                $order->update_status(
                    'pending',
                    sprintf(
                        'M-Pesa STK Push sent. MerchantRequestID: %s | CheckoutRequestID: %s. Awaiting customer confirmation.',
                        sanitize_text_field( $body['MerchantRequestID'] ),
                        sanitize_text_field( $body['CheckoutRequestID'] )
                    )
                );

                WC()->cart->empty_cart();

                return [
                    'result'   => 'success',
                    'redirect' => $this->get_return_url( $order ),
                ];
            }

            // API returned a non-zero ResponseCode.
            $error_msg = $body['errorMessage'] ?? $body['ResponseDescription'] ?? 'Unknown error from M-Pesa API.';
            $this->log->error( '[M-Pesa STK] STK Push failed: ' . $error_msg, [ 'source' => 'mpesa-stk' ] );
            wc_add_notice( 'M-Pesa payment failed: ' . esc_html( $error_msg ), 'error' );
            return [ 'result' => 'failure' ];
        }

        // -----------------------------------------------------------
        // 7. Callback Handler — Safaricom POSTs results here.
        // -----------------------------------------------------------
        public function handle_callback(): void {
            $raw_body = file_get_contents( 'php://input' );
            $this->log->info( '[M-Pesa STK] Callback received: ' . $raw_body, [ 'source' => 'mpesa-stk' ] );

            $data = json_decode( $raw_body );

            if ( ! $data || ! isset( $data->Body->stkCallback ) ) {
                $this->log->error( '[M-Pesa STK] Invalid callback payload.', [ 'source' => 'mpesa-stk' ] );
                status_header( 400 );
                wp_send_json( [ 'ResultCode' => 1, 'ResultDesc' => 'Invalid payload' ] );
                exit;
            }

            $callback          = $data->Body->stkCallback;
            $result_code       = (int) $callback->ResultCode;
            $checkout_req_id   = sanitize_text_field( $callback->CheckoutRequestID ?? '' );
            $merchant_req_id   = sanitize_text_field( $callback->MerchantRequestID ?? '' );

            // Find the order by CheckoutRequestID stored in order meta.
            $orders = wc_get_orders( [
                'meta_key'   => '_mpesa_checkout_request_id',
                'meta_value' => $checkout_req_id,
                'limit'      => 1,
            ] );

            if ( empty( $orders ) ) {
                $this->log->error( '[M-Pesa STK] No order found for CheckoutRequestID: ' . $checkout_req_id, [ 'source' => 'mpesa-stk' ] );
                wp_send_json( [ 'ResultCode' => 0, 'ResultDesc' => 'Accepted' ] );
                exit;
            }

            $order = $orders[0];

            if ( 0 === $result_code ) {
                // Success: extract receipt number from CallbackMetadata.
                $receipt_number = '';
                $amount_paid    = '';
                $phone_used     = '';

                if ( isset( $callback->CallbackMetadata->Item ) ) {
                    foreach ( $callback->CallbackMetadata->Item as $item ) {
                        switch ( $item->Name ) {
                            case 'MpesaReceiptNumber':
                                $receipt_number = sanitize_text_field( $item->Value ?? '' );
                                break;
                            case 'Amount':
                                $amount_paid = sanitize_text_field( $item->Value ?? '' );
                                break;
                            case 'PhoneNumber':
                                $phone_used = sanitize_text_field( $item->Value ?? '' );
                                break;
                        }
                    }
                }

                $order->update_meta_data( '_mpesa_receipt_number', $receipt_number );
                $order->payment_complete( $receipt_number );
                $order->add_order_note(
                    sprintf(
                        'M-Pesa payment confirmed. Receipt: %s | Amount: KES %s | Phone: %s',
                        $receipt_number,
                        $amount_paid,
                        $phone_used
                    )
                );
                $order->save();

                $this->log->info(
                    '[M-Pesa STK] Payment success for Order #' . $order->get_id() . '. Receipt: ' . $receipt_number,
                    [ 'source' => 'mpesa-stk' ]
                );

            } else {
                // Failure: log and mark order as failed.
                $result_desc = sanitize_text_field( $callback->ResultDesc ?? 'Payment cancelled or failed.' );
                $order->update_status(
                    'failed',
                    'M-Pesa payment failed/cancelled. Reason: ' . $result_desc . ' | CheckoutRequestID: ' . $checkout_req_id
                );

                $this->log->warning(
                    '[M-Pesa STK] Payment failed for Order #' . $order->get_id() . '. ResultCode: ' . $result_code . ' | ' . $result_desc,
                    [ 'source' => 'mpesa-stk' ]
                );
            }

            // Always respond 200 to Safaricom so they stop retrying.
            status_header( 200 );
            wp_send_json( [ 'ResultCode' => 0, 'ResultDesc' => 'Accepted' ] );
            exit;
        }

        // -----------------------------------------------------------
        // 8. Internal helpers.
        // -----------------------------------------------------------

        /**
         * Get OAuth 2.0 access token from Daraja.
         * Returns the token string on success or WP_Error on failure.
         */
        private function get_access_token(): string|WP_Error {
            $consumer_key    = $this->get_option( 'consumer_key' );
            $consumer_secret = $this->get_option( 'consumer_secret' );

            $response = wp_remote_get(
                $this->get_endpoint( 'oauth' ),
                [
                    'headers' => [
                        // Basic auth: base64( consumerKey:consumerSecret )
                        'Authorization' => 'Basic ' . base64_encode( $consumer_key . ':' . $consumer_secret ),
                    ],
                    'timeout' => 20,
                ]
            );

            if ( is_wp_error( $response ) ) {
                return $response;
            }

            $body = json_decode( wp_remote_retrieve_body( $response ), true );

            if ( empty( $body['access_token'] ) ) {
                return new WP_Error(
                    'mpesa_token_error',
                    'Could not retrieve access token. Response: ' . wp_json_encode( $body )
                );
            }

            return $body['access_token'];
        }

        /**
         * Return the correct Daraja API endpoint URL.
         *
         * SANDBOX base:    https://sandbox.safaricom.co.ke
         * PRODUCTION base: https://api.safaricom.co.ke
         *
         * Swap happens here. Change the environment in WooCommerce settings,
         * never edit these URLs manually.
         */
        private function get_endpoint( string $type ): string {
            $env = $this->get_option( 'environment', 'sandbox' );

            // Base URLs: sandbox vs. production.
            $base = 'production' === $env
                ? 'https://api.safaricom.co.ke'       // PRODUCTION: live payments
                : 'https://sandbox.safaricom.co.ke';  // SANDBOX: safe for testing

            return match ( $type ) {
                'oauth'    => $base . '/oauth/v1/generate?grant_type=client_credentials',
                'stkpush'  => $base . '/mpesa/stkpush/v1/processrequest',
                default    => $base,
            };
        }
    }
}
